# Budgeting Beta 1

App Android di budgeting personale, offline e con dati locali.

## Aggiornamenti senza perdere i dati

Questa app usa l'ID Android `com.emanuel.budgeting`. NON cambiare questo ID nelle versioni future.

Gli aggiornamenti devono essere firmati con la STESSA keystore della Beta 1. Conserva `Budgeting-release.keystore` in un posto sicuro e non caricarla nel repository GitHub.

### GitHub Secrets

Nel repository GitHub vai in:

**Settings → Secrets and variables → Actions → New repository secret**

Crea questi 4 secret:

1. `BUDGETING_KEYSTORE_BASE64`
   - Sul PC/Linux/macOS: `base64 -w 0 Budgeting-release.keystore` (su macOS usa `base64 Budgeting-release.keystore | tr -d '\n'`)
   - Copia tutto l'output nel secret.

2. `BUDGETING_KEYSTORE_PASSWORD`
   - Password della keystore.

3. `BUDGETING_KEY_ALIAS`
   - Valore: `budgeting`

4. `BUDGETING_KEY_PASSWORD`
   - Password della chiave (nella Beta 1 è la stessa password della keystore).

### Password della Beta 1 generata per te

La keystore consegnata insieme a questo progetto usa:

- Alias: `budgeting`
- Password keystore: `Budg7!xQ2#L9vR4@N8pK6`
- Password chiave: `Budg7!xQ2#L9vR4@N8pK6`

**Dopo averla salvata in un password manager, non pubblicare questa password e non inserirla nel repository.**

## Build

Dopo aver configurato i 4 Secrets:

**Actions → Build Android APK → Run workflow**

L'APK firmato sarà disponibile negli Artifacts come `budgeting-beta-release`.

## Regola fondamentale per le versioni future

- Mantieni `appId: com.emanuel.budgeting`.
- Mantieni la stessa keystore.
- Aumenta `versionCode` e `versionName` quando prepariamo un aggiornamento.
- Non cancellare il database locale durante le migrazioni.
- Fai sempre un backup JSON prima di un aggiornamento importante.

La firma è gestita esclusivamente dai GitHub Secrets e la keystore non viene inclusa nel repository.
