(() => {
  'use strict';
  const KEY='budgeting_beta_v2';
  const APP_VERSION='0.3.1';
  const defaults={accounts:[],cards:[],debts:[],categories:{expense:['Alimentari','Casa','Bar','Trasporti','Svago','Abbigliamento','Bollette','Salute','Altro'],income:['Stipendio','Rimborsi','Extra','Altro']},ops:[],privacy:false};
  let state=loadState(), catKind='expense', viewDate=new Date(), opsDate=new Date();
  const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
  const eur=n=>new Intl.NumberFormat('it-IT',{style:'currency',currency:'EUR'}).format(Number(n)||0);
  const moneyInputValue=n=>Number(n||0).toFixed(2).replace('.',',');
  function parseMoney(value){
    const s=String(value??'').trim().replace(/\s/g,'');
    if(!s)return NaN;
    if(!/^\d+(?:,\d{0,2})?$/.test(s))return NaN;
    const [a,b='']=s.split(',');
    return Number(a+'.'+(b+'00').slice(0,2));
  }
  function bindMoneyInput(id){
    const el=$(id);
    if(!el)return;
    el.addEventListener('input',()=>{el.value=el.value.replace(/[^0-9,]/g,'').replace(/(,.*),/g,'$1');const parts=el.value.split(',');if(parts[1]?.length>2)el.value=parts[0]+','+parts[1].slice(0,2);});
    el.addEventListener('blur',()=>{const n=parseMoney(el.value);if(Number.isFinite(n))el.value=moneyInputValue(n);});
  }
  const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const isoToday=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
  const monthKey=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
  const fmtMonth=d=>new Intl.DateTimeFormat('it-IT',{month:'long',year:'numeric'}).format(d);
  const fmtDate=s=>new Intl.DateTimeFormat('it-IT',{day:'2-digit',month:'2-digit',year:'numeric'}).format(new Date(`${s}T12:00:00`));
  function cloneDefaults(){return JSON.parse(JSON.stringify(defaults))}
  function normalizeState(x){
    const base=cloneDefaults();
    const out={...base,...(x||{}),categories:{...base.categories,...((x&&x.categories)||{})},ops:Array.isArray(x?.ops)?x.ops:[]};
    out.accounts=Array.isArray(out.accounts)?out.accounts:[];
    out.cards=Array.isArray(out.cards)?out.cards:[];
    out.debts=Array.isArray(out.debts)?out.debts:[];
    return out;
  }
  function loadState(){
    try{
      const keys=[KEY,'budgeting_beta_v1','budgeting_beta','budgeting'];
      let raw=null;
      for(const k of keys){const v=localStorage.getItem(k);if(v){raw=v;break}}
      if(!raw)return cloneDefaults();
      const x=JSON.parse(raw);
      const out=normalizeState(x);
      // Migrazione: l'utilizzato delle vecchie carte diventa un debito, senza doppio conteggio.
      const oldCards=Array.isArray(x.cards)?x.cards:[];
      if(oldCards.length){
        out.cards=out.cards.map(c=>({...c,used:0}));
        oldCards.forEach(c=>{const used=Number(c.used)||0;if(used>0){out.debts.push({person:c.name||'Carta di credito',remaining:used,note:'Debito carta di credito',source:'credit-card'});}});
      }
      // Salva subito nella chiave attuale, così le versioni successive trovano sempre gli stessi dati.
      localStorage.setItem(KEY,JSON.stringify(out));
      return out;
    }catch(e){return cloneDefaults()}
  }
  function save(){localStorage.setItem(KEY,JSON.stringify(state));render()}
  function totals(){const cash=state.accounts.reduce((s,a)=>s+(+a.balance||0),0),debt=state.debts.reduce((s,d)=>s+(+d.remaining||0),0);return {cash,debt,net:cash-debt}}
  function render(){const t=totals();setText('#netBalance',state.privacy?'••••••':eur(t.net));setText('#cashTotal',state.privacy?'••••':eur(t.cash));setText('#debtTotal',state.privacy?'••••':eur(t.debt));renderAccounts();renderCategories();renderOps();renderStats()}
  function setText(sel,v){const el=$(sel);if(el)el.textContent=v}
  function renderAccounts(){
    $('#accountsList').innerHTML=state.accounts.map((x,i)=>`<div class="account" data-account="${i}"><div class="row"><div class="avatar">${esc((x.name||'?')[0].toUpperCase())}</div><div class="grow"><div class="name">${esc(x.name)}</div><div class="small">Conto corrente / contanti</div></div><div class="amount">${state.privacy?'••••':eur(x.balance)}</div></div></div>`).join('')||'<div class="add-empty">Nessun conto. Aggiungi il primo conto.</div>';
    $('#cardsList').innerHTML=state.cards.map((x,i)=>{const limit=+x.limit||0;return `<div class="card" data-card="${i}"><div class="row"><div class="avatar">${esc((x.name||'C')[0].toUpperCase())}</div><div class="grow"><div class="name">${esc(x.name)}</div><div class="small">Plafond ${eur(limit)} · L'utilizzato viene registrato nei Debiti</div></div><div class="amount">${state.privacy?'••••':eur(limit)}</div></div></div>`}).join('')||'<div class="add-empty">Nessuna carta di credito.</div>';
    $('#debtsList').innerHTML=state.debts.map((x,i)=>`<div class="debt" data-debt="${i}"><div class="row"><div class="avatar">${esc((x.person||'D')[0].toUpperCase())}</div><div class="grow"><div class="name">${esc(x.person)}</div><div class="small">${esc(x.note||'Debito')}</div></div><div class="amount red">${state.privacy?'••••':eur(x.remaining)}</div></div></div>`).join('')||'<div class="add-empty">Nessun debito attivo.</div>';
    $$('[data-account]').forEach(el=>el.onclick=()=>editAccount(+el.dataset.account));
    $$('[data-card]').forEach(el=>el.onclick=()=>editCard(+el.dataset.card));
    $$('[data-debt]').forEach(el=>el.onclick=()=>editDebt(+el.dataset.debt));
  }
  function renderCategories(){const m=monthKey(viewDate),ops=state.ops.filter(o=>monthKey(new Date(`${o.date}T12:00:00`))===m);const exp=ops.filter(o=>o.type==='expense').reduce((s,o)=>s+o.amount,0),inc=ops.filter(o=>o.type==='income').reduce((s,o)=>s+o.amount,0);setText('#monthLabel',fmtMonth(viewDate));setText('#monthExpenses',eur(exp));setText('#monthIncome',eur(inc));$('#categoriesList').innerHTML=state.categories[catKind].map(c=>{const sum=ops.filter(o=>o.type===catKind&&o.category===c).reduce((s,o)=>s+o.amount,0);return `<div class="cat"><div class="cat-name">${esc(c)}</div><div class="cat-amount ${catKind==='expense'?'red':'green'}">${eur(sum)}</div></div>`}).join('')}
  function renderOps(){setText('#opsMonthLabel',fmtMonth(opsDate));const m=monthKey(opsDate),arr=state.ops.filter(o=>monthKey(new Date(`${o.date}T12:00:00`))===m).sort((a,b)=>String(b.date).localeCompare(String(a.date)));let html='',last='';arr.forEach(o=>{const d=fmtDate(o.date);if(d!==last){html+=`<div class="op-date">${d}</div>`;last=d}const income=o.type==='income',transfer=o.type==='transfer',adjust=o.type==='adjustment',sign=income?'+':transfer?'↔':adjust?(o.amount>=0?'+':'-'):'-';const color=income?'green':transfer||adjust?'':'red';html+=`<div class="op"><div class="avatar">${income?'↑':transfer?'↔':adjust?'✎':'↓'}</div><div class="grow"><div class="name">${esc(o.title||o.category)}</div><div class="small">${esc(o.accountName||'')} · ${esc(o.category||'')}</div></div><div class="amount ${color}">${sign}${eur(Math.abs(o.amount))}</div></div>`});$('#operationsList').innerHTML=html||'<div class="add-empty">Nessuna operazione nel mese.</div>'}
  function renderStats(){const m=monthKey(viewDate),ops=state.ops.filter(o=>monthKey(new Date(`${o.date}T12:00:00`))===m),inc=ops.filter(o=>o.type==='income').reduce((s,o)=>s+o.amount,0),exp=ops.filter(o=>o.type==='expense').reduce((s,o)=>s+o.amount,0);setText('#statIncome',eur(inc));setText('#statExpense',eur(exp));setText('#statSaving',eur(inc-exp));drawPie(state.categories.expense.map(c=>[c,ops.filter(o=>o.type==='expense'&&o.category===c).reduce((s,o)=>s+o.amount,0)]).filter(x=>x[1]>0))}
  function drawPie(vals){const c=$('#pieChart');if(!c)return;const ctx=c.getContext('2d'),w=c.width,h=c.height;ctx.clearRect(0,0,w,h);if(!vals.length){ctx.beginPath();ctx.arc(w/2,h/2,90,0,Math.PI*2);ctx.strokeStyle='#29364d';ctx.lineWidth=28;ctx.stroke();$('#chartLegend').innerHTML='<div class="add-empty">Nessuna spesa nel mese.</div>';return}const total=vals.reduce((s,x)=>s+x[1],0),colors=['#86b7ff','#42d39b','#ffd166','#ff6680','#a78bfa','#5dd6e8','#ff9f66','#7dd3fc'];let start=-Math.PI/2;vals.forEach((x,i)=>{const ang=x[1]/total*Math.PI*2;ctx.beginPath();ctx.moveTo(w/2,h/2);ctx.arc(w/2,h/2,105,start,start+ang);ctx.closePath();ctx.fillStyle=colors[i%colors.length];ctx.fill();start+=ang});ctx.beginPath();ctx.arc(w/2,h/2,55,0,Math.PI*2);ctx.fillStyle='#121a2a';ctx.fill();$('#chartLegend').innerHTML=vals.map(x=>`<div class="legend"><span>${esc(x[0])}</span><b>${eur(x[1])}</b></div>`).join('')}
  function modal(html){$('#modalContent').innerHTML=html;$('#modal').classList.remove('hidden')}
  function close(){ $('#modal').classList.add('hidden') }
  function editAccount(i=null){const x=i===null?{name:'',balance:0}:{...state.accounts[i]};modal(`<h2>${i===null?'Nuovo conto':'Modifica conto'}</h2><div class="form"><label>Nome<input id="fName" value="${esc(x.name)}" placeholder="Revolut"></label><label>Saldo attuale<input id="fAmount" class="money-input" inputmode="decimal" value="${moneyInputValue(x.balance)}" placeholder="0,00"></label><button class="primary" id="saveBtn">Salva</button>${i!==null?'<button class="danger" id="delBtn">Elimina conto</button>':''}</div>`);$('#saveBtn').onclick=()=>{const n=$('#fName').value.trim();if(!n)return alert('Inserisci il nome del conto');const b=parseMoney($('#fAmount').value);if(!Number.isFinite(b)||b<0)return alert('Inserisci un importo valido, ad esempio 125,50');if(i===null)state.accounts.push({name:n,balance:b});else state.accounts[i]={...state.accounts[i],name:n,balance:b};close();save()};if(i!==null)$('#delBtn').onclick=()=>{if(confirm('Eliminare questo conto?')){state.accounts.splice(i,1);close();save()}}}
  function editCard(i=null){const x=i===null?{name:'',limit:0,used:0}:{...state.cards[i]};modal(`<h2>${i===null?'Nuova carta di credito':'Modifica carta'}</h2><div class="form"><div class="hint">La carta non crea una voce separata nel patrimonio. Quando utilizzi la carta, inserisci l'importo direttamente nei Debiti.</div><label>Nome<input id="fName" value="${esc(x.name)}" placeholder="Carta personale"></label><label>Plafond<input id="fLimit" class="money-input" inputmode="decimal" value="${moneyInputValue(x.limit)}" placeholder="0,00"></label><button class="primary" id="saveBtn">Salva</button>${i!==null?'<button class="danger" id="delBtn">Elimina carta</button>':''}</div>`);$('#saveBtn').onclick=()=>{const n=$('#fName').value.trim();if(!n)return alert('Inserisci il nome');const limit=parseMoney($('#fLimit').value);if(!Number.isFinite(limit)||limit<0)return alert('Inserisci un plafond valido, ad esempio 1000,00');const x={name:n,limit,used:0};if(i===null)state.cards.push(x);else state.cards[i]=x;close();save()};if(i!==null)$('#delBtn').onclick=()=>{if(confirm('Eliminare questa carta?')){state.cards.splice(i,1);close();save()}}}
  function editDebt(i=null){const x=i===null?{person:'',remaining:0,note:''}:{...state.debts[i]};modal(`<h2>${i===null?'Nuovo debito':'Gestisci debito'}</h2><div class="form"><label>Persona / ente<input id="fPerson" value="${esc(x.person)}" placeholder="Marco"></label><label>Importo residuo<input id="fAmount" class="money-input" inputmode="decimal" value="${moneyInputValue(x.remaining)}" placeholder="0,00"></label><label>Nota<input id="fNote" value="${esc(x.note||'')}" placeholder="Prestito, spesa..." ></label><button class="primary" id="saveBtn">Salva</button>${i!==null?'<button class="secondary" id="payBtn">💶 Paga una parte</button><button class="danger" id="delBtn">Elimina debito</button>':''}</div>`);$('#saveBtn').onclick=()=>{const p=$('#fPerson').value.trim();if(!p)return alert('Inserisci il creditore');const remaining=parseMoney($('#fAmount').value);if(!Number.isFinite(remaining)||remaining<0)return alert('Inserisci un importo valido, ad esempio 250,00');const item={person:p,remaining,note:$('#fNote').value.trim()};if(i===null)state.debts.push(item);else state.debts[i]={...state.debts[i],...item};close();save()};if(i!==null){$('#payBtn').onclick=()=>{close();payDebt(i)};$('#delBtn').onclick=()=>{if(confirm('Eliminare questo debito?')){state.debts.splice(i,1);close();save()}}}}
  function payDebt(i){const d=state.debts[i];if(!d)return;if(!state.accounts.length)return alert('Prima crea almeno un conto.');const opts=state.accounts.map((a,n)=>`<option value="${n}">${esc(a.name)}</option>`).join('');modal(`<h2>Pagamento a ${esc(d.person)}</h2><div class="form"><div class="hint">Residuo: <b>${eur(d.remaining)}</b>. Il pagamento riduce il conto e il debito, ma non viene conteggiato come normale spesa.</div><label>Conto<select id="fAccount">${opts}</select></label><label>Importo<input id="fAmount" class="money-input" inputmode="decimal" value="${moneyInputValue(d.remaining)}" placeholder="0,00"></label><label>Data<input id="fDate" type="date" value="${isoToday()}"></label><button class="primary" id="saveBtn">Registra pagamento</button></div>`);$('#saveBtn').onclick=()=>{const ai=Number($('#fAccount').value),amt=parseMoney($('#fAmount').value);if(!Number.isFinite(amt)||amt<=0||amt>d.remaining)return alert('Importo non valido');const a=state.accounts[ai];a.balance-=amt;d.remaining=Math.max(0,d.remaining-amt);state.ops.push({type:'debtPayment',amount:amt,category:'Debito',date:$('#fDate').value,title:`Pagamento a ${d.person}`,accountName:a.name});if(d.remaining===0)state.debts.splice(i,1);close();save()}}
  function addCategory(){modal(`<h2>Nuova categoria</h2><div class="form"><label>Tipo<select id="fKind"><option value="expense">Spesa</option><option value="income">Entrata</option></select></label><label>Nome<input id="fName" placeholder="Nuova categoria"></label><button class="primary" id="saveBtn">Aggiungi</button></div>`);$('#saveBtn').onclick=()=>{const k=$('#fKind').value,n=$('#fName').value.trim();if(!n)return alert('Inserisci il nome');if(!state.categories[k].includes(n))state.categories[k].push(n);close();save()}}
  function addTransaction(){if(!state.accounts.length)return alert('Prima crea almeno un conto.');const opts=state.accounts.map((a,i)=>`<option value="${i}">${esc(a.name)}</option>`).join('');modal(`<h2>Nuova operazione</h2><div class="form"><label>Tipo<select id="fType"><option value="expense">Spesa</option><option value="income">Entrata</option></select></label><label>Conto<select id="fAccount">${opts}</select></label><label>Importo<input id="fAmount" class="money-input" inputmode="decimal" placeholder="0,00"></label><label>Categoria<select id="fCategory"></select></label><label>Data<input id="fDate" type="date" value="${isoToday()}"></label><label>Descrizione<input id="fTitle" placeholder="Facoltativa"></label><button class="primary" id="saveBtn">Salva operazione</button></div>`);const update=()=>{const k=$('#fType').value;$('#fCategory').innerHTML=state.categories[k].map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('')};$('#fType').onchange=update;update();$('#saveBtn').onclick=()=>{const type=$('#fType').value,ai=Number($('#fAccount').value),amount=parseMoney($('#fAmount').value);if(!Number.isFinite(amount)||amount<=0)return alert('Inserisci un importo');const a=state.accounts[ai];a.balance+=type==='income'?amount:-amount;state.ops.push({type,amount,category:$('#fCategory').value,date:$('#fDate').value,title:$('#fTitle').value.trim(),accountName:a.name});close();save()}}
  function transfer(){if(state.accounts.length<2)return alert('Servono almeno due conti.');const opts=state.accounts.map((a,i)=>`<option value="${i}">${esc(a.name)}</option>`).join('');modal(`<h2>Trasferimento</h2><div class="form"><label>Da<select id="fFrom">${opts}</select></label><label>A<select id="fTo">${opts}</select></label><label>Importo<input id="fAmount" class="money-input" inputmode="decimal" placeholder="0,00"></label><button class="primary" id="saveBtn">Trasferisci</button></div>`);$('#saveBtn').onclick=()=>{const f=Number($('#fFrom').value),t=Number($('#fTo').value),amt=parseMoney($('#fAmount').value);if(f===t||!Number.isFinite(amt)||amt<=0)return alert('Controlla conti e importo');if(amt>state.accounts[f].balance)return alert('Saldo insufficiente');state.accounts[f].balance-=amt;state.accounts[t].balance+=amt;state.ops.push({type:'transfer',amount:amt,category:'Trasferimento',date:isoToday(),title:'Trasferimento tra conti',accountName:`${state.accounts[f].name} → ${state.accounts[t].name}`});close();save()}}
  function adjust(){if(!state.accounts.length)return alert('Prima crea almeno un conto.');const opts=state.accounts.map((a,i)=>`<option value="${i}">${esc(a.name)}</option>`).join('');modal(`<h2>Rettifica saldo</h2><div class="form"><div class="hint">Inserisci la differenza da aggiungere o togliere dal saldo. Esempio: +10 oppure -10.</div><label>Conto<select id="fAccount">${opts}</select></label><label>Variazione<input id="fAmount" class="money-input" inputmode="decimal" placeholder="10,00"></label><label>Motivo<input id="fTitle" placeholder="Allineamento saldo"></label><button class="primary" id="saveBtn">Registra rettifica</button></div>`);$('#saveBtn').onclick=()=>{const ai=Number($('#fAccount').value),raw=$('#fAmount').value.trim(),delta=(raw.startsWith('-')?-1:1)*parseMoney(raw.replace(/^[-+]/,''));if(!Number.isFinite(delta)||delta===0)return alert('Inserisci una variazione');const a=state.accounts[ai];a.balance+=delta;state.ops.push({type:'adjustment',amount:delta,category:'Rettifica',date:isoToday(),title:$('#fTitle').value.trim()||'Rettifica saldo',accountName:a.name});close();save()}}
  function more(){
    modal(`<h2>Altro</h2><div class="form"><button class="secondary menu-btn" id="backup"><b>💾 Esporta backup</b><span>Salva tutti i dati in un file JSON</span></button><button class="secondary menu-btn" id="restore"><b>♻️ Ripristina backup</b><span>Importa un file JSON precedentemente salvato</span></button><button class="danger menu-btn" id="reset"><b>⚠️ Azzera dati</b><span>Elimina definitivamente i dati presenti sul telefono</span></button><input id="file" type="file" accept="application/json" hidden></div>`);
    const file=$('#file');
    if(file) file.addEventListener('change',e=>{
      const selected=e.target.files&&e.target.files[0];
      if(!selected)return;
      const r=new FileReader();
      r.onload=()=>{
        try{
          const x=JSON.parse(r.result);
          if(!x||!Array.isArray(x.accounts)||!Array.isArray(x.ops))throw new Error();
          state=normalizeState(x);
          save();
          close();
          alert('Backup ripristinato');
        }catch(_){alert('File non valido')}
        e.target.value='';
      };
      r.readAsText(selected);
    });
  }
  function backup(){const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='budgeting-backup.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}
  function bind(){
    $('#closeModal').onclick=close;$('#modal').onclick=e=>{if(e.target.id==='modal')close()};$('#addAccount').onclick=()=>editAccount();$('#addCard').onclick=()=>editCard();$('#addDebt').onclick=()=>editDebt();$('#addCategory').onclick=addCategory;$('#fab').onclick=()=>modal(`<h2>Nuova operazione</h2><div class="form"><button class="primary" id="expense">＋ Spesa / entrata</button><button class="secondary" id="transfer">↔ Trasferimento tra conti</button><button class="secondary" id="debt">🤝 Pagamento debito</button><button class="secondary" id="adjust">✎ Rettifica saldo</button></div>`);$('#moreBtn').onclick=more;
    document.addEventListener('click',e=>{const id=e.target.id;if(id==='expense'){close();addTransaction()}else if(id==='transfer'){close();transfer()}else if(id==='debt'){close();if(state.debts.length)payDebt(0);else alert('Prima crea un debito.')}else if(id==='adjust'){close();adjust()}else if(id==='backup'){backup()}else if(id==='restore'){$('#file').click()}else if(id==='reset'&&confirm('Cancellare tutti i dati?')){localStorage.removeItem(KEY);location.reload()}});
    document.addEventListener('input',e=>{const el=e.target;if(!el.classList.contains('money-input'))return;el.value=el.value.replace(/[^0-9,\-]/g,'').replace(/(,.*),/g,'$1').replace(/(?!^)-/g,'');const parts=el.value.replace(/^-/,'').split(',');if(parts[1]?.length>2)el.value=(el.value.startsWith('-')?'-':'')+parts[0].replace(/^-/,'')+','+parts[1].slice(0,2)});
    document.addEventListener('blur',e=>{const el=e.target;if(!el.classList.contains('money-input'))return;const raw=el.value.trim(),negative=raw.startsWith('-'),n=parseMoney(raw.replace(/^[-+]/,''));if(Number.isFinite(n))el.value=(negative?'-':'')+moneyInputValue(n)},{capture:true});
    $('#privacyBtn').onclick=()=>{state.privacy=!state.privacy;save()};
    $$('.switch button').forEach(b=>b.onclick=()=>{$$('.switch button').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');catKind=b.dataset.kind;renderCategories()});
    $$('.nav[data-tab]').forEach(b=>{b.type='button';b.addEventListener('click',()=>openTab(b.dataset.tab));b.addEventListener('touchend',e=>{e.preventDefault();openTab(b.dataset.tab)},{passive:false})});
    function openTab(tab){const b=$(`.nav[data-tab=\"${tab}\"]`);if(!b)return;$$('.nav').forEach(x=>x.classList.remove('active'));b.classList.add('active');$$('.tab').forEach(x=>x.classList.remove('active'));const panel=$('#tab-'+tab);if(panel)panel.classList.add('active');render()}

    $('#prevMonth').onclick=()=>{viewDate.setMonth(viewDate.getMonth()-1);renderCategories();renderStats()};$('#nextMonth').onclick=()=>{viewDate.setMonth(viewDate.getMonth()+1);renderCategories();renderStats()};$('#prevOpsMonth').onclick=()=>{opsDate.setMonth(opsDate.getMonth()-1);renderOps()};$('#nextOpsMonth').onclick=()=>{opsDate.setMonth(opsDate.getMonth()+1);renderOps()};
  }
  document.addEventListener('DOMContentLoaded',()=>{bind();render()});
})();
