# Budgeting Beta 2

Personal Android budgeting app, local/offline. Data is stored on the phone. Backup/restore uses a local JSON file.

## GitHub secrets
Keep these existing repository secrets unchanged:
- BUDGETING_KEYSTORE_BASE64
- BUDGETING_KEYSTORE_PASSWORD
- BUDGETING_KEY_ALIAS
- BUDGETING_KEY_PASSWORD

Do not commit the keystore.

## Update safety
Keep appId `com.emanuel.budgeting` and the same release keystore for future APK updates. Never uninstall the app if you want to preserve local data.
