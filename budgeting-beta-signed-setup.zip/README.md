# Budgeting 0.4.0

App Android locale per gestione di conti, entrate, spese, categorie, budget, debiti e statistiche.

## Dati
- Tutti i dati restano sul dispositivo tramite localStorage.
- Backup e ripristino tramite file JSON dalla sezione **Altro**.
- Non vengono usate integrazioni bancarie o server esterni.

## Build GitHub Actions
Il workflow crea il progetto Android Capacitor, installa l'icona personalizzata, configura la firma tramite i Secrets GitHub già presenti e produce l'APK release.

**Importante:** per gli aggiornamenti mantenere lo stesso `appId` (`com.emanuel.budgeting`) e la stessa chiave di firma.

## Novità grafiche 0.4.0
- Interfaccia scura più pulita con card, gerarchie visive e spaziatura migliorate.
- Testata con icona dell'app e riepilogo mensile.
- Dashboard con entrate, spese, debiti e risparmio del mese.
- Modali più leggibili e barra di trascinamento.
- Icona launcher Android personalizzata e icone web.
